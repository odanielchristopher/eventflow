"""FastAPI dependency providers."""
